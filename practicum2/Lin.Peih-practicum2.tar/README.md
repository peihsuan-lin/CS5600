## Run client
% ./client WRITE <local_file_path> <remote_file_path>


## Mutiple clients
- WRITE: server applying file protection
- GET: save_file() client applying file protection